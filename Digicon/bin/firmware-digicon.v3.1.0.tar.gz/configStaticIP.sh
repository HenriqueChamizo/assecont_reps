#!/bin/sh

# Consistências

if [ "$#" = "0" ]; then
    echo "Modo de uso: "$0" <interface de rede> <IP> [<mascara de rede> <gateway>]"
    exit 1;
fi

# Interface de rede
INTF=$1
# IP do dispositivo
IP=$2
# Mascara de rede
NETMASK=$3
# Gateway/Router default
GATEWAY=$4

# Configura a interface $INTF
echo "Configurando a interface "$INTF
ifconfig $INTF down 2> /dev/null
ifconfig $INTF up 2> /dev/null
# Se a interface não existir, sai
if [ $? -ne 0 ] ;then
    echo "Erro ao ativar interface "$INTF", script abortado!"
    exit 1;
fi

# Se não informou mascara de rede, limita-a para apenas o ultimo byte para host
if [ "x$NETMASK" = "x" ]; then 
    NETMASK="netmask 255.255.255.0"
else
    NETMASK="netmask "$NETMASK
fi

echo "Configurando "$INTF" com IP "$IP" e mascara "$NETMASK
ifconfig $INTF $IP $NETMASK

# Configura as rotas utilizando o $GATEWAY
echo "Configurando gateway e rotas"

#apaga todas as rotas, para evitar que o firmware tente utilizar alguma rota antiga
route del default gw 0.0.0.0 dev $INTF 2> /dev/null

if [ "x$GATEWAY" != "x" ]; then
	echo "Adcionando "$GATEWAY" como roteador padrao"
	route add default gw $GATEWAY dev $INTF
	# se ocorreu algum problema ao alterar o gateway
	if [ $? -ne 0 ] ;then
		echo "Erro ao adicionar o host "$GATEWAY " como gateway da interface "$INTF
		return;
	fi
else
	echo "Gateway nao definido, sem roteador padrao configurado"
fi


