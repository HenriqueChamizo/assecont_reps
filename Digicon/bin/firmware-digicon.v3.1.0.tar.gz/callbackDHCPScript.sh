#!/bin/sh

CONF_SCRIPT="/mnt/flash/firmware/scripts/configStaticIP.sh"

case "$1" in
  bound)
    echo "_BOUND_"
    $CONF_SCRIPT $interface $ip $subnet $router
  ;;

  renew)
    echo "_RENEW_"
    $CONF_SCRIPT $interface $ip $subnet $router
  ;;

  deconfig)
    echo "_DECONFIG_"
    ifconfig $interface 0.0.0.0
  ;;

  *)
    echo "Usage: $0 {bound|renew|deconfig}"
    exit 1
    ;;
esac

exit 0
