#!/bin/sh

# Consistências

if [ "$#" = "0" ]; then
	echo "Modo de uso $0 <interface de rede> [<script DHCP>]"
	return;
fi

# Interface utilizada pelo DHCP
INTF=$1

# Se foi passado um segundo argumento, utiliza-o como sendo o script do dhcp
if [ "x$2" != "x" ]; then 
    DHCP_SCRIPT=$2
elif
    DHCP_SCRIPT="/mnt/flash/firmware/scripts/callbackDHCPScript.sh"
fi

echo "Inicializando DHCP na interface "$INTF" com o script "$DHCP_SCRIPT
udhcpc -f -i $INTF -s $DHCP_SCRIPT &
