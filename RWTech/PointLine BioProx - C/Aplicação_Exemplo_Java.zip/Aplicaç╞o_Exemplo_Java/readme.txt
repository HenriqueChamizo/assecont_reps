A aplica��o "SimuladorIntegracaoREP.jar" foi desenvolvida para auxiliar os desenvolvedores no processo de integra��o com os rel�gios de ponto da linha iPointline RWTECH.

Antes de execut�-la, � necess�rio instalar o Java e, posteriormente, substituir os arquivos "local_policy.jar" e "US_export_policy.jar" no diret�rio "lib\security" do Java instalado.